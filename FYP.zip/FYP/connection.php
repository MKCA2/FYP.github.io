<?php
$serverName = ""
$database = "DBTutorials"
$uid = "";
$password = "";
$connection = [
    "Database" => "DBTutorials",
    "Uid" => "",
    "PWD" => ""
];

$conn = sqlsrv_connect($serverName, $connection);
if($conn)
    die(print_r(sqlsrv_errors(), true));
else
echo 'Connection Success';

?>