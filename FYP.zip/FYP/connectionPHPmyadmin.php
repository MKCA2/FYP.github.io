<?
$connection = mysqli_connect("localhost:3310", "root","", "sensorsdb")

if(!$connection){
    die("Error".mysql_connect_error());
} else{

}

?>  