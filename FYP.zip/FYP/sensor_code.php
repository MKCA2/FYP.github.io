<?php
require 'D:/xampp/htdocs/testcode/FYP/PHPMailer-master/src/PHPMailer.php';
require 'D:/xampp/htdocs/testcode/FYP/PHPMailer-master/src/SMTP.php';
require 'D:/xampp/htdocs/testcode/FYP/PHPMailer-master/src/Exception.php';


use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

session_start();
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$db = "sensorsdatabase";

$conn = mysqli_connect($dbhost, $dbuser, $dbpass, $db);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

echo "Database connection is OK<br>";

if (isset($_POST["temperature"]) && isset($_POST["humidity"]) && isset($_POST["co2"])) {
    $t = $_POST["temperature"];
    $h = $_POST["humidity"];
    $co2 = $_POST["co2"];

    $sql = "INSERT INTO sensors (temperature, humidity, co2) VALUES (" . $t . ", " . $h . ", " . $co2 . ")";

    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";

        // Check if CO2 level is above the threshold
        $co2Threshold = 1000; // Set your desired CO2 threshold here

        if ($co2 > $co2Threshold) {
            echo "CO2 level is above the threshold. Sending email notification...";

            // Email details
            $to = "azaz.awesome@gmail.com"; // Replace with the actual email address of the user
        $subject = "CO2 Level Alert";
        $message = "The CO2 level is above the threshold!"; // Modify the message as needed

            $mail = new PHPMailer(true);

            try {
                //Server settings
                $mail->SMTPDebug = 0; // Set to 2 for detailed debugging information
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server host
                $mail->SMTPAuth = true;
                $mail->Username = 'calvinchan0513@gmail.com'; // Replace with your SMTP username
                $mail->Password = 'igfrwearefaeffeawawawhvyzixnzgrbrc'; // Replace with your SMTP password
                $mail->SMTPSecure = 'tls'; // Set to 'ssl' if using SSL
                $mail->Port = 587; // Set the appropriate port: 587 for TLS, 465 for SSL

               // Recipients
               $mail->setFrom('calvinchan0513@gmail.com', 'Admin'); // Replace with your email address and name
              $mail->addAddress($to);

                //Content
                $mail->isHTML(true);
                $mail->Subject = 'High CO2 Level Notification';
                $mail->Body = 'The CO2 level is above the threshold. CO2 Level: ' . $co2;

                $mail->send();
                echo "Email sent successfully";
            } catch (Exception $e) {
                echo "Failed to send email. Error: " . $mail->ErrorInfo;
            }
        }
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}
?>


